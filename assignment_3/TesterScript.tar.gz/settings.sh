# Note: this script is always executed on the same host as the GraderClient
export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64
export HOSTS="localhost localhost localhost"
export HEAPGB=3
export SSH_OPTS="-i ~/.ssh/id_rsa -o StrictHostKeyChecking=no"
